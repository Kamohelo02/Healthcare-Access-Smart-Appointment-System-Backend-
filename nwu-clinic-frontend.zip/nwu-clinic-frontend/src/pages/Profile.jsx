// src/pages/Profile.jsx (Full Corrected Code)
import React, { useState, useEffect } from 'react';
import '../styles/ProfilePage.css';

const Profile = () => {
  // State to toggle between view and edit modes
  const [isEditing, setIsEditing] = useState(false);

  // State to hold the current user data
  const [userData, setUserData] = useState({
    name: 'Loading...',
    studentNumber: 'Loading...',
    email: 'Loading...',
    phone: 'Loading...',
  });

  // State to hold form data while editing
  const [formData, setFormData] = useState({ phone: '' });

  // State for password change form
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  
  // State for feedback messages
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // Load user data from localStorage when the component mounts
  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem('user'));
    if (storedUser) {
      // In a real app, you'd fetch this from the /profile API endpoint
      setUserData({
        name: storedUser.name || 'N/A',
        studentNumber: '34567890', // Placeholder, get from user object if available
        email: storedUser.email || 'N/A',
        phone: '082 123 4567', // Placeholder, get from user object if available
      });
    }
  }, []);

  // Handlers for editing profile information
  const handleEditToggle = () => {
    setFormData({ phone: userData.phone }); // Pre-fill form with current data
    setIsEditing(true);
    setSuccessMessage('');
    setErrorMessage('');
  };

  const handleCancel = () => {
    setIsEditing(false);
  };
  
  const handleProfileInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleProfileUpdate = (e) => {
    e.preventDefault();
    // Simulate API call to update profile
    console.log('Updating profile with:', formData);
    setUserData(prev => ({ ...prev, phone: formData.phone })); // Update UI optimistically
    // In a real app: localStorage.setItem('user', JSON.stringify(updatedUser))
    setSuccessMessage('Profile updated successfully!');
    setIsEditing(false);
  };

  // Handlers for changing password
  const handlePasswordInputChange = (e) => {
    const { name, value } = e.target;
    setPasswordData(prev => ({ ...prev, [name]: value }));
  };

  const handlePasswordUpdate = (e) => {
    e.preventDefault();
    if (passwordData.newPassword !== passwordData.confirmPassword) {
        setErrorMessage('New passwords do not match.');
        return;
    }
    // Simulate API call to change password
    console.log('Changing password...');
    setSuccessMessage('Password changed successfully!');
    setErrorMessage('');
    setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
  };

  return (
    <div className="profile-container">
      <header className="profile-header">
        <h1>My Profile</h1>
      </header>
      
      {/* --- Personal Information Card --- */}
      <form className="profile-card" onSubmit={handleProfileUpdate}>
        <div className="card-header">
          <h2>Personal Information</h2>
          {!isEditing && <button type="button" className="edit-btn" onClick={handleEditToggle}>Edit</button>}
        </div>

        <div className="profile-grid">
          {/* Non-editable fields */}
          <div className="form-group">
            <label>Full Name</label>
            <div className="value">{userData.name}</div>
          </div>
          <div className="form-group">
            <label>Student Number</label>
            <div className="value">{userData.studentNumber}</div>
          </div>

          {/* Email (usually not editable) */}
          <div className="form-group">
            <label>Email Address</label>
            <div className="value">{userData.email}</div>
          </div>

          {/* Editable phone number field */}
          <div className="form-group">
            <label htmlFor="phone">Phone Number</label>
            {isEditing ? (
              <input 
                type="tel" 
                id="phone" 
                name="phone"
                value={formData.phone}
                onChange={handleProfileInputChange}
              />
            ) : (
              <div className="value">{userData.phone}</div>
            )}
          </div>
          
          {isEditing && (
            <div className="form-actions">
              <button type="submit" className="action-btn primary">Save Changes</button>
              <button type="button" className="action-btn secondary" onClick={handleCancel}>Cancel</button>
            </div>
          )}
        </div>
      </form>
      
      {/* --- Password Change Card --- */}
      <form className="password-card" onSubmit={handlePasswordUpdate}>
        <div className="card-header">
          <h2>Change Password</h2>
        </div>
        <div className="profile-grid">
          <div className="form-group">
            <label htmlFor="currentPassword">Current Password</label>
            <input type="password" id="currentPassword" name="currentPassword" value={passwordData.currentPassword} onChange={handlePasswordInputChange} />
          </div>
          <div className="form-group">
            <label htmlFor="newPassword">New Password</label>
            <input type="password" id="newPassword" name="newPassword" value={passwordData.newPassword} onChange={handlePasswordInputChange} />
          </div>
          <div className="form-group">
            <label htmlFor="confirmPassword">Confirm New Password</label>
            <input type="password" id="confirmPassword" name="confirmPassword" value={passwordData.confirmPassword} onChange={handlePasswordInputChange} />
          </div>
          <div className="form-actions">
            <button type="submit" className="action-btn primary">Update Password</button>
          </div>
        </div>
      </form>

      {successMessage && <div className="feedback-message success">{successMessage}</div>}
      {errorMessage && <div className="feedback-message error">{errorMessage}</div>}
    </div>
  );
};

export default Profile;