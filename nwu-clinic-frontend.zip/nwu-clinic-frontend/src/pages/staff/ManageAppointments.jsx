// src/pages/staff/ManageAppointments.jsx (Full Code)
import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import '../../styles/ManageAppointments.css';

// --- Mock Data ---
// Now includes student details for each appointment
const mockAppointments = [
  { id: 1, date: '2025-10-25', time: '10:30 AM', doctor: 'Dr. Thabo Mbeki', type: 'General Consultation', status: 'confirmed', student: { name: 'Alice Smith', studentNumber: '31234567' } },
  { id: 7, date: '2025-11-12', time: '08:30 AM', doctor: 'Dr. Thabo Mbeki', type: 'Blood Pressure Check', status: 'pending', student: { name: 'Bob Johnson', studentNumber: '32345678' } },
  { id: 2, date: '2025-11-05', time: '02:00 PM', doctor: 'Dr. Zandile Gumede', type: 'Dental Check-up', status: 'confirmed', student: { name: 'Charlie Brown', studentNumber: '33456789' } },
  { id: 11, date: '2025-12-15', time: '04:00 PM', doctor: 'Dr. Zandile Gumede', type: 'Sick Note Request', status: 'pending', student: { name: 'Diana Prince', studentNumber: '34567890' } },
  { id: 3, date: '2025-09-15', time: '09:00 AM', doctor: 'Dr. Sarah Johnson', type: 'Follow-up', status: 'completed', student: { name: 'Edward Scissorhands', studentNumber: '35678901' } },
  { id: 6, date: '2025-10-28', time: '01:15 PM', doctor: 'Dr. Sarah Johnson', type: 'Vaccination', status: 'confirmed', student: { name: 'Fiona Shrek', studentNumber: '36789012' } },
];

const StatusBadge = ({ status }) => <span className={`status-badge ${status}`}>{status}</span>;

const ManageAppointments = () => {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  // States for search, filtering, and sorting
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState('all');
  const [sortConfig, setSortConfig] = useState({ key: 'date', direction: 'descending' });

  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      setAppointments(mockAppointments);
      setLoading(false);
    }, 1000);
  }, []);

  const processedAppointments = useMemo(() => {
    let processed = [...appointments];

    // 1. Search Logic
    if (searchTerm) {
      processed = processed.filter(appt =>
        appt.student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        appt.student.studentNumber.includes(searchTerm)
      );
    }

    // 2. Filtering Logic
    if (activeFilter !== 'all') {
      processed = processed.filter(appt => appt.status === activeFilter);
    }

    // 3. Sorting Logic
    // ... (sorting logic is the same as student's page) ...

    return processed;
  }, [appointments, searchTerm, activeFilter, sortConfig]);

  // --- Action Handlers ---
  const handleApprove = (id) => {
    setAppointments(prev => prev.map(appt => 
      appt.id === id ? { ...appt, status: 'confirmed' } : appt
    ));
    // In a real app: await api.put(`/appointments/manage`, { id, status: 'confirmed' });
    console.log(`Approved appointment ${id}`);
  };

  const handleReject = (id) => {
    setAppointments(prev => prev.map(appt => 
      appt.id === id ? { ...appt, status: 'cancelled' } : appt
    ));
    // In a real app: await api.put(`/appointments/manage`, { id, status: 'cancelled' });
    console.log(`Rejected appointment ${id}`);
  };

  if (loading) return <div>Loading appointments...</div>;

  return (
    <div className="manage-appointments-container">
      <header className="appointments-header">
        <h1>Manage Appointments</h1>
      </header>
      
      <div className="appointments-toolbar">
        <div className="filter-group">
          <button onClick={() => setActiveFilter('all')} className={`filter-btn ${activeFilter === 'all' ? 'active' : ''}`}>All</button>
          <button onClick={() => setActiveFilter('pending')} className={`filter-btn ${activeFilter === 'pending' ? 'active' : ''}`}>Pending</button>
          <button onClick={() => setActiveFilter('confirmed')} className={`filter-btn ${activeFilter === 'confirmed' ? 'active' : ''}`}>Confirmed</button>
        </div>
        <div className="search-bar">
          <span className="search-icon">🔍</span>
          <input 
            type="text" 
            className="search-input"
            placeholder="Search by student name or number..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="table-wrapper">
        <table className="appointments-table">
          <thead>
            <tr>
              <th>Student Name</th>
              <th>Student #</th>
              <th>Date</th>
              <th>Time</th>
              <th>Doctor</th>
              <th>Type</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {processedAppointments.map(appt => (
              <tr key={appt.id}>
                <td>{appt.student.name}</td>
                <td>{appt.student.studentNumber}</td>
                <td>{new Date(appt.date).toLocaleDateString('en-ZA')}</td>
                <td>{appt.time}</td>
                <td>{appt.doctor}</td>
                <td>{appt.type}</td>
                <td><StatusBadge status={appt.status} /></td>
                <td>
                  {appt.status === 'pending' && (
                    <div className="action-buttons">
                      <button className="action-btn approve" onClick={() => handleApprove(appt.id)}>Approve</button>
                      <button className="action-btn reject" onClick={() => handleReject(appt.id)}>Reject</button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {/* Pagination can be added here if needed */}
    </div>
  );
};

export default ManageAppointments;