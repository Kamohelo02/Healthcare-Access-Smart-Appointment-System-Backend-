// src/pages/staff/ManageAvailability.jsx (Full Code)
import React, { useState, useEffect } from 'react';
import '../../styles/ManageAvailability.css';

// --- Mock Data ---
// In a real app, this would be fetched from an API for the logged-in staff member
const initialAvailability = {
  Monday: ['09:00 AM', '09:30 AM', '10:00 AM', '02:00 PM', '02:30 PM'],
  Tuesday: ['09:00 AM', '09:30 AM', '10:00 AM', '10:30 AM'],
  Wednesday: [],
  Thursday: ['10:00 AM', '10:30 AM', '11:00 AM', '03:00 PM'],
  Friday: ['09:00 AM', '09:30 AM', '10:00 AM'],
};

const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

const ManageAvailability = () => {
  const [availability, setAvailability] = useState({});
  const [loading, setLoading] = useState(true);
  
  // State to manage which day is currently being edited
  const [selectedDay, setSelectedDay] = useState(null);
  
  // State for the new time input field
  const [newTime, setNewTime] = useState('');

  // Simulate fetching the schedule on component mount
  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      setAvailability(initialAvailability);
      setLoading(false);
    }, 500);
  }, []);

  const handleDaySelect = (day) => {
    setSelectedDay(selectedDay === day ? null : day); // Toggle selection
    setNewTime(''); // Reset input field on day change
  };
  
  // Handler for adding a new time slot
  const handleTimeAdd = (e) => {
    e.preventDefault();
    if (newTime && selectedDay && !availability[selectedDay].includes(newTime)) {
      // Add the new time and sort the array
      const updatedTimes = [...availability[selectedDay], newTime].sort();
      setAvailability({ ...availability, [selectedDay]: updatedTimes });
      setNewTime(''); // Clear input
      
      // In a real app, you would post this update to the backend API
      console.log(`Added ${newTime} to ${selectedDay}`);
    }
  };
  
  // Handler for removing a time slot
  const handleTimeRemove = (day, timeToRemove) => {
    const updatedTimes = availability[day].filter(time => time !== timeToRemove);
    setAvailability({ ...availability, [day]: updatedTimes });
    
    // In a real app, you would post this update to the backend API
    console.log(`Removed ${timeToRemove} from ${day}`);
  };

  if (loading) {
    return <div>Loading your schedule...</div>;
  }
  
  return (
    <div className="availability-container">
      <header className="availability-header">
        <h1>Manage My Availability</h1>
      </header>
      
      <div className="week-view">
        {daysOfWeek.map(day => (
          <div key={day} className={`day-card ${selectedDay === day ? 'active' : ''}`}>
            <div className="day-header">
              <h2>{day}</h2>
              <button className="manage-btn" onClick={() => handleDaySelect(day)}>
                {selectedDay === day ? 'Close' : 'Manage'}
              </button>
            </div>
            
            <div className="time-slots-list">
              {availability[day]?.length > 0 ? (
                availability[day].map(time => (
                  <div key={time} className="time-slot-tag">
                    {time}
                    {selectedDay === day && (
                      <button className="remove-time-btn" onClick={() => handleTimeRemove(day, time)}>
                        &times;
                      </button>
                    )}
                  </div>
                ))
              ) : (
                <p>No available slots.</p>
              )}
            </div>

            {/* Form for adding a new time slot, shown only for the selected day */}
            {selectedDay === day && (
              <div className="edit-day-section">
                <h3>Add a new time slot</h3>
                <form className="add-time-form" onSubmit={handleTimeAdd}>
                  <input
                    type="time"
                    className="add-time-input"
                    value={newTime}
                    onChange={(e) => setNewTime(e.target.value)}
                  />
                  <button type="submit" className="add-time-btn">Add</button>
                </form>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ManageAvailability;