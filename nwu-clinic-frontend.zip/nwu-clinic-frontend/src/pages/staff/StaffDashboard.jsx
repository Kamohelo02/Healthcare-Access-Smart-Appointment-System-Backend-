// src/pages/staff/StaffDashboard.jsx (Full Updated Code)
import React, { useState, useEffect } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import DashboardLayout from '../components/DashboardLayout';
import ManageAppointments from './ManageAppointments';
import ManageAvailability from './ManageAvailability';

// FIXED: All 'to' paths are now absolute
const staffMenuItems = [
  { to: "/staff/dashboard", icon: "🗓️", label: "Manage Appointments", description: "View & approve bookings" },
  { to: "/staff/dashboard/availability", icon: "⏰", label: "My Availability", description: "Set your working hours" },
];

const StaffDashboard = () => {
  const navigate = useNavigate();
  const [userData, setUserData] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user || user.role !== 'staff') {
      navigate('/login');
      return;
    }
    setUserData({
      firstName: user.name?.split(' ')[0] || 'Clinic',
      lastName: user.name?.split(' ')[1] || 'Staff',
      email: user.email,
      identifier: 'Clinic Staff',
    });
    setLoading(false);
  }, [navigate]);

  if (loading) {
    return <div>Loading Staff Dashboard...</div>;
  }

  return (
    <DashboardLayout userData={userData} menuItems={staffMenuItems}>
      <Routes>
        <Route index element={<ManageAppointments />} />
        <Route path="availability" element={<ManageAvailability />} />
      </Routes>
    </DashboardLayout>
  );
};

export default StaffDashboard;