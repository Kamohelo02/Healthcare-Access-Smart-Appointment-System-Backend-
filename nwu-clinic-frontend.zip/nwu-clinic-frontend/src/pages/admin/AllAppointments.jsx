// src/pages/admin/AllAppointments.jsx (Full Code)
import React, { useState, useEffect, useMemo } from 'react';
import '../../styles/ManageAppointments.css'; // We can reuse the staff's CSS

// --- Mock Data ---
// A comprehensive list of all appointments in the system
const mockAllAppointments = [
  { id: 1, date: '2025-10-25', time: '10:30 AM', doctor: 'Dr. Thabo Mbeki', type: 'General Consultation', status: 'confirmed', student: { name: 'Alice Smith', studentNumber: '31234567' } },
  { id: 7, date: '2025-11-12', time: '08:30 AM', doctor: 'Dr. Thabo Mbeki', type: 'Blood Pressure Check', status: 'pending', student: { name: 'Bob Johnson', studentNumber: '32345678' } },
  { id: 3, date: '2025-09-15', time: '09:00 AM', doctor: 'Dr. Sarah Johnson', type: 'Follow-up', status: 'completed', student: { name: 'Edward Scissorhands', studentNumber: '35678901' } },
  { id: 5, date: '2025-09-10', time: '03:30 PM', doctor: 'Dr. Zandile Gumede', type: 'Sick Note Request', status: 'cancelled', student: { name: 'Diana Prince', studentNumber: '34567890' } },
  { id: 2, date: '2025-11-05', time: '02:00 PM', doctor: 'Dr. Zandile Gumede', type: 'Dental Check-up', status: 'confirmed', student: { name: 'Charlie Brown', studentNumber: '33456789' } },
  { id: 6, date: '2025-10-28', time: '01:15 PM', doctor: 'Dr. Sarah Johnson', type: 'Vaccination', status: 'confirmed', student: { name: 'Fiona Shrek', studentNumber: '36789012' } },
];

const StatusBadge = ({ status }) => <span className={`status-badge ${status}`}>{status}</span>;

const AllAppointments = () => {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  useEffect(() => {
    // Simulate fetching all appointments from GET /admin/appointments
    setLoading(true);
    setTimeout(() => {
      setAppointments(mockAllAppointments);
      setLoading(false);
    }, 500);
  }, []);

  const filteredAppointments = useMemo(() => {
    return appointments
      .filter(appt => filterStatus === 'all' || appt.status === filterStatus)
      .filter(appt =>
        appt.student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        appt.student.studentNumber.includes(searchTerm)
      );
  }, [appointments, filterStatus, searchTerm]);

  // --- Admin Action Handlers ---
  const handleCancelAppointment = (id) => {
    if (window.confirm('Are you sure you want to cancel this appointment? This action cannot be undone.')) {
        setAppointments(prev => prev.map(appt => 
        appt.id === id ? { ...appt, status: 'cancelled' } : appt
      ));
      // In a real app: await api.put(`/admin/appointments/${id}`, { status: 'cancelled' });
      console.log(`Admin cancelled appointment ${id}`);
    }
  };

  const handleEditAppointment = (id) => {
    // This would typically open a modal with a form to edit the appointment details
    alert(`Admin is editing appointment ${id}. (Feature to be built)`);
  };

  if (loading) return <div>Loading all appointments...</div>;

  return (
    <div className="manage-appointments-container">
      <header className="appointments-header">
        <h1>All System Appointments</h1>
      </header>
      
      <div className="appointments-toolbar">
        <div className="filter-group">
          <button onClick={() => setFilterStatus('all')} className={`filter-btn ${filterStatus === 'all' ? 'active' : ''}`}>All</button>
          <button onClick={() => setFilterStatus('pending')} className={`filter-btn ${filterStatus === 'pending' ? 'active' : ''}`}>Pending</button>
          <button onClick={() => setFilterStatus('confirmed')} className={`filter-btn ${filterStatus === 'confirmed' ? 'active' : ''}`}>Confirmed</button>
          <button onClick={() => setFilterStatus('completed')} className={`filter-btn ${filterStatus === 'completed' ? 'active' : ''}`}>Completed</button>
          <button onClick={() => setFilterStatus('cancelled')} className={`filter-btn ${filterStatus === 'cancelled' ? 'active' : ''}`}>Cancelled</button>
        </div>
        <div className="search-bar">
          <span className="search-icon">🔍</span>
          <input 
            type="text" 
            className="search-input"
            placeholder="Search by student name or number..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="table-wrapper">
        <table className="appointments-table">
          <thead>
            <tr>
              <th>Student Name</th>
              <th>Student #</th>
              <th>Date</th>
              <th>Time</th>
              <th>Doctor</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredAppointments.map(appt => (
              <tr key={appt.id}>
                <td>{appt.student.name}</td>
                <td>{appt.student.studentNumber}</td>
                <td>{new Date(appt.date).toLocaleDateString('en-ZA')}</td>
                <td>{appt.time}</td>
                <td>{appt.doctor}</td>
                <td><StatusBadge status={appt.status} /></td>
                <td>
                  <div className="action-buttons">
                    <button className="action-btn approve" onClick={() => handleEditAppointment(appt.id)}>Edit</button>
                    <button 
                      className="action-btn reject" 
                      onClick={() => handleCancelAppointment(appt.id)}
                      disabled={appt.status === 'cancelled' || appt.status === 'completed'}
                    >
                      Cancel
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AllAppointments;