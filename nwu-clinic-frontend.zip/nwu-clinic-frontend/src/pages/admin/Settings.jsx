// src/pages/admin/Settings.jsx (Full Code)
import React, { useState, useEffect } from 'react';
import '../../styles/SettingsPage.css';

const Settings = () => {
  const [settings, setSettings] = useState({
    maxAppointmentsPerDay: '',
    bookingWindowDays: '',
    clinicOpenTime: '',
    clinicCloseTime: '',
  });
  const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  // Simulate fetching current settings on component mount
  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      // In a real app, this data would come from GET /admin/settings
      setSettings({
        maxAppointmentsPerDay: 50,
        bookingWindowDays: 14,
        clinicOpenTime: '08:00',
        clinicCloseTime: '17:00',
      });
      setLoading(false);
    }, 1000);
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSettings(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSaving(true);
    setSuccessMessage('');

    // Simulate an API call to save the settings
    // In a real app: await api.post('/admin/settings', settings);
    console.log('Saving settings:', settings);

    setTimeout(() => {
      setIsSaving(false);
      setSuccessMessage('Settings have been updated successfully!');
      
      // Hide success message after a few seconds
      setTimeout(() => setSuccessMessage(''), 5000);
    }, 1500);
  };

  if (loading) {
    return <div>Loading settings...</div>;
  }

  return (
    <div className="settings-container">
      <header className="settings-header">
        <h1>System Settings</h1>
      </header>

      <form className="settings-card" onSubmit={handleSubmit}>
        <h2>Booking Rules</h2>
        <div className="settings-grid">
          <div className="form-group">
            <label htmlFor="maxAppointmentsPerDay">Max Daily Appointments</label>
            <input 
              type="number" 
              id="maxAppointmentsPerDay"
              name="maxAppointmentsPerDay"
              value={settings.maxAppointmentsPerDay}
              onChange={handleInputChange}
            />
          </div>
          <div className="form-group">
            <label htmlFor="bookingWindowDays">Booking Window (in days)</label>
            <input 
              type="number" 
              id="bookingWindowDays"
              name="bookingWindowDays"
              placeholder="e.g., 14"
              value={settings.bookingWindowDays}
              onChange={handleInputChange}
            />
          </div>
          <div className="form-group">
            <label htmlFor="clinicOpenTime">Clinic Open Time</label>
            <input 
              type="time" 
              id="clinicOpenTime"
              name="clinicOpenTime"
              value={settings.clinicOpenTime}
              onChange={handleInputChange}
            />
          </div>
          <div className="form-group">
            <label htmlFor="clinicCloseTime">Clinic Close Time</label>
            <input 
              type="time" 
              id="clinicCloseTime"
              name="clinicCloseTime"
              value={settings.clinicCloseTime}
              onChange={handleInputChange}
            />
          </div>
        </div>
        
        <div className="form-actions">
          <button type="submit" className="save-btn" disabled={isSaving}>
            {isSaving ? 'Saving...' : 'Save Settings'}
          </button>
        </div>
      </form>

      {successMessage && <div className="success-message">{successMessage}</div>}
    </div>
  );
};

export default Settings;