// src/pages/admin/AdminDashboard.jsx (Full Updated Code)
import React, { useState, useEffect } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import DashboardLayout from '../components/DashboardLayout';
import UserManagement from './UserManagement';
import AllAppointments from './AllAppointments';
import Settings from './Settings'; // <-- IMPORT THE NEW COMPONENT

const adminMenuItems = [
  { to: "/admin/dashboard", icon: "👥", label: "Manage Users", description: "Add or remove users" },
  { to: "/admin/dashboard/analytics", icon: "📊", label: "Analytics", description: "View system stats" },
  { to: "/admin/dashboard/appointments", icon: "📋", label: "All Appointments", description: "Oversee all bookings" },
  { to: "/admin/dashboard/settings", icon: "⚙️", label: "Settings", description: "Configure system rules" },
];

// Reusable placeholder component for other pages
const Placeholder = ({ title }) => (
  <div className="page-placeholder"><div className="placeholder-content"><h2>{title}</h2><div className="coming-soon-badge">Coming Soon</div></div></div>
);

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [userData, setUserData] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user || user.role !== 'admin') {
      navigate('/login');
      return;
    }
    setUserData({
      firstName: user.name?.split(' ')[0] || 'Admin',
      lastName: user.name?.split(' ')[1] || 'User',
      email: user.email,
      identifier: 'Administrator',
    });
    setLoading(false);
  }, [navigate]);

  if (loading) {
    return <div>Loading Administrator Dashboard...</div>;
  }

  return (
    <DashboardLayout userData={userData} menuItems={adminMenuItems}>
      <Routes>
        <Route index element={<UserManagement />} />
        <Route path="analytics" element={<Placeholder title="Analytics Page" />} />
        <Route path="appointments" element={<AllAppointments />} />
        {/* This route now renders your new, functional settings page */}
        <Route path="settings" element={<Settings />} />
      </Routes>
    </DashboardLayout>
  );
};

export default AdminDashboard;