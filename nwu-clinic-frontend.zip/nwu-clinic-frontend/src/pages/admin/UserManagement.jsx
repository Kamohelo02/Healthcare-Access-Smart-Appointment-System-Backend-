// src/pages/admin/UserManagement.jsx (Full Code)
import React, { useState, useEffect, useMemo } from 'react';
import '../../styles/UserManagement.css';

// --- Mock Data ---
// In a real app, this would be fetched from your GET /admin/users endpoint
const mockUsers = [
  { id: 1, name: 'Alice Smith', email: 'alice.s@student.nwu.ac.za', role: 'student', status: 'active' },
  { id: 2, name: 'Bob Johnson', email: 'bob.j@student.nwu.ac.za', role: 'student', status: 'active' },
  { id: 3, name: 'Sarah Johnson', email: 'sarah.nurse@nwu.ac.za', role: 'staff', status: 'active' },
  { id: 4, name: 'Charlie Brown', email: 'charlie.b@student.nwu.ac.za', role: 'student', status: 'inactive' },
  { id: 5, name: 'Lisa Martinez', email: 'clinic.staff@nwu.ac.za', role: 'staff', status: 'active' },
  { id: 6, name: 'Diana Prince', email: 'diana.p@student.nwu.ac.za', role: 'student', status: 'active' },
];

const RoleBadge = ({ role }) => <span className={`role-badge ${role}`}>{role}</span>;

const StatusToggle = ({ user, onToggle }) => {
  const isActive = user.status === 'active';
  return (
    <div className="status-toggle">
      <label className="switch">
        <input 
          type="checkbox" 
          checked={isActive}
          onChange={() => onToggle(user.id)}
        />
        <span className="slider"></span>
      </label>
      <span className={`status-text ${isActive ? 'active' : 'inactive'}`}>
        {isActive ? 'Active' : 'Inactive'}
      </span>
    </div>
  );
};

const UserManagement = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  // States for search and filtering
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('all');

  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      setUsers(mockUsers);
      setLoading(false);
    }, 500);
  }, []);

  // Filter and search users
  const filteredUsers = useMemo(() => {
    return users
      .filter(user => filterRole === 'all' || user.role === filterRole)
      .filter(user => 
        user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        user.email.toLowerCase().includes(searchTerm.toLowerCase())
      );
  }, [users, filterRole, searchTerm]);

  // Handler for toggling a user's status
  const handleStatusToggle = (userId) => {
    setUsers(currentUsers => 
      currentUsers.map(user => {
        if (user.id === userId) {
          const newStatus = user.status === 'active' ? 'inactive' : 'active';
          // In a real app, you would make an API call here:
          // api.put(`/admin/users/${userId}`, { status: newStatus });
          console.log(`Setting user ${userId} status to ${newStatus}`);
          return { ...user, status: newStatus };
        }
        return user;
      })
    );
  };

  if (loading) return <div>Loading user list...</div>;

  return (
    <div className="user-management-container">
      <header className="user-management-header">
        <h1>User Management</h1>
      </header>
      
      <div className="user-toolbar">
        <div className="filter-group">
          <button onClick={() => setFilterRole('all')} className={`filter-btn ${filterRole === 'all' ? 'active' : ''}`}>All</button>
          <button onClick={() => setFilterRole('student')} className={`filter-btn ${filterRole === 'student' ? 'active' : ''}`}>Students</button>
          <button onClick={() => setFilterRole('staff')} className={`filter-btn ${filterRole === 'staff' ? 'active' : ''}`}>Staff</button>
        </div>
        <div className="search-bar">
          <span className="search-icon">🔍</span>
          <input 
            type="text" 
            className="search-input"
            placeholder="Search by name or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="table-wrapper">
        <table className="users-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {filteredUsers.map(user => (
              <tr key={user.id}>
                <td>{user.name}</td>
                <td>{user.email}</td>
                <td><RoleBadge role={user.role} /></td>
                <td><StatusToggle user={user} onToggle={handleStatusToggle} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default UserManagement;