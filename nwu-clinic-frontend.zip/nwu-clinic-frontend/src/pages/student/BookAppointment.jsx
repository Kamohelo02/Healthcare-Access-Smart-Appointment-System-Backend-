// src/pages/student/BookAppointment.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../../styles/BookAppointment.css';

// --- Mock Data ---
const services = [
  { id: 'general', name: 'General Consultation', icon: '🩺' },
  { id: 'dental', name: 'Dental Check-up', icon: '🦷' },
  { id: 'vaccination', name: 'Vaccination', icon: '💉' },
  { id: 'follow-up', name: 'Follow-up Visit', icon: '🔁' },
];

const getAvailableTimeSlots = (date) => {
  // In a real app, this would be an API call to the backend
  console.log('Fetching available times for:', date.toDateString());
  // Mock different times for different days
  const day = date.getDay();
  if (day === 0 || day === 6) return []; // No appointments on weekends
  if (day % 2 === 0) {
    return ['09:00 AM', '10:00 AM', '11:00 AM', '02:00 PM', '03:00 PM'];
  }
  return ['09:30 AM', '10:30 AM', '11:30 AM', '02:30 PM', '03:30 PM'];
};

const BookAppointment = () => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [bookingDetails, setBookingDetails] = useState({
    service: null,
    date: new Date(),
    time: null,
    notes: '',
  });
  const [isBooked, setIsBooked] = useState(false);

  const availableTimes = getAvailableTimeSlots(bookingDetails.date);

  const handleServiceSelect = (service) => setBookingDetails({ ...bookingDetails, service });
  const handleDateChange = (day) => {
    const newDate = new Date(bookingDetails.date);
    newDate.setDate(day);
    setBookingDetails({ ...bookingDetails, date: newDate, time: null }); // Reset time when date changes
  };
  const handleTimeSelect = (time) => setBookingDetails({ ...bookingDetails, time });
  const handleNotesChange = (e) => setBookingDetails({ ...bookingDetails, notes: e.target.value });
  
  const nextStep = () => setCurrentStep(prev => prev + 1);
  const prevStep = () => setCurrentStep(prev => prev - 1);

  const handleConfirmBooking = () => {
    console.log('Booking Confirmed:', bookingDetails);
    // TODO: Replace with actual API call to POST /appointments
    setTimeout(() => {
      setIsBooked(true);
    }, 1500);
  };

  // --- Render Functions for Each Step ---

  const renderStep1 = () => (
    <div>
      <h2>Step 1: Select a Service</h2>
      <div className="service-grid">
        {services.map(s => (
          <div 
            key={s.id} 
            className={`service-card ${bookingDetails.service?.id === s.id ? 'selected' : ''}`}
            onClick={() => handleServiceSelect(s)}
          >
            <div className="service-icon">{s.icon}</div>
            <h3>{s.name}</h3>
          </div>
        ))}
      </div>
    </div>
  );

  const renderStep2 = () => {
    const today = new Date();
    today.setHours(0,0,0,0); // Set to start of day for accurate comparison
    const date = bookingDetails.date;
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDayOfWeek = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    return (
      <div>
        <h2>Step 2: Choose a Date & Time</h2>
        <div className="date-time-picker">
          <div className="calendar">
            <h3>{date.toLocaleString('en-ZA', { month: 'long', year: 'numeric' })}</h3>
            <div className="calendar-grid">
              {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map(d => <div key={d} className="day-name">{d}</div>)}
              {Array.from({ length: firstDayOfWeek }).map((_, i) => <div key={`empty-${i}`}></div>)}
              {Array.from({ length: daysInMonth }).map((_, i) => {
                const day = i + 1;
                const currentDate = new Date(year, month, day);
                const isSelected = day === date.getDate();
                const isDisabled = currentDate < today;
                return (
                  <div 
                    key={day} 
                    className={`day-cell ${isSelected ? 'selected' : ''} ${isDisabled ? 'disabled' : ''}`}
                    onClick={() => !isDisabled && handleDateChange(day)}
                  >
                    {day}
                  </div>
                );
              })}
            </div>
          </div>
          <div className="time-slots">
            <h3>Available Times</h3>
            <div className="time-grid">
              {availableTimes.length > 0 ? availableTimes.map(time => (
                <div 
                  key={time} 
                  className={`time-slot ${bookingDetails.time === time ? 'selected' : ''}`}
                  onClick={() => handleTimeSelect(time)}
                >
                  {time}
                </div>
              )) : <p>No slots available on this day.</p>}
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderStep3 = () => (
    <div>
      <h2>Step 3: Confirm Your Details</h2>
      <div className="confirmation-summary">
        <ul>
          <li><span>Service</span> <strong>{bookingDetails.service?.name}</strong></li>
          <li><span>Date</span> <strong>{bookingDetails.date.toLocaleDateString('en-ZA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</strong></li>
          <li><span>Time</span> <strong>{bookingDetails.time}</strong></li>
        </ul>
        <label htmlFor="notes" className="notes-label">Optional Notes</label>
        <textarea
            id="notes"
            className="notes-textarea"
            placeholder="Add any notes for the clinic (e.g., specific symptoms)..."
            value={bookingDetails.notes}
            onChange={handleNotesChange}
        ></textarea>
      </div>
    </div>
  );
  
  if (isBooked) {
      return (
          <div className="success-message">
              <div className="success-icon">✅</div>
              <h2>Appointment Booked!</h2>
              <p>Your appointment has been successfully scheduled. You will receive a confirmation email shortly.</p>
              <button className="nav-btn primary" onClick={() => navigate('/student/appointments')}>View My Appointments</button>
          </div>
      );
  }

  const stepperSteps = ['Select Service', 'Select Date & Time', 'Confirm'];
  const progressWidth = ((currentStep - 1) / (stepperSteps.length - 1)) * 100;

  return (
    <div className="booking-container">
      <header className="booking-header"><h1>Book an Appointment</h1></header>
      
      <div className="stepper">
        <div className="progress-bar" style={{ width: `${progressWidth}%` }}></div>
        {stepperSteps.map((label, index) => (
            <div key={label} className={`step ${index + 1 <= currentStep ? 'active' : ''}`}>
                <div className="step-number">{index + 1}</div>
                <div className="step-label">{label}</div>
            </div>
        ))}
      </div>

      <div className="step-content">
        {currentStep === 1 && renderStep1()}
        {currentStep === 2 && renderStep2()}
        {currentStep === 3 && renderStep3()}
      </div>

      <div className="navigation-buttons">
        <button className="nav-btn secondary" onClick={prevStep} disabled={currentStep === 1}>Back</button>
        {currentStep < 3 ? (
          <button className="nav-btn primary" onClick={nextStep} disabled={ (currentStep === 1 && !bookingDetails.service) || (currentStep === 2 && !bookingDetails.time) }>Next</button>
        ) : (
          <button className="nav-btn primary" onClick={handleConfirmBooking}>Confirm Booking</button>
        )}
      </div>
    </div>
  );
};

export default BookAppointment;