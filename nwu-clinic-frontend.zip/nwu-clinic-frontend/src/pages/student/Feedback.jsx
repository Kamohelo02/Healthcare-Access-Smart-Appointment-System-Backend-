// src/pages/student/Feedback.jsx (Full Code)
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import '../../styles/FeedbackPage.css';

const Feedback = () => {
  const [rating, setRating] = useState(0); // 0 means no rating given yet
  const [hover, setHover] = useState(0);
  const [comment, setComment] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (rating === 0) {
      alert('Please select a star rating before submitting.');
      return;
    }
    // Simulate sending data to the backend POST /feedback endpoint
    console.log('Submitting feedback:', { rating, comment });
    setIsSubmitted(true);
  };
  
  if (isSubmitted) {
    return (
      <div className="thank-you-message">
        <div className="thank-you-icon">🎉</div>
        <h2>Thank You!</h2>
        <p>Your feedback has been submitted. We appreciate you taking the time to help us improve our services.</p>
        <Link to="/student" className="back-btn">Back to Dashboard</Link>
      </div>
    );
  }

  return (
    <div className="feedback-container">
      <header className="feedback-header">
        <h1>Share Your Experience</h1>
      </header>
      
      <form className="feedback-card" onSubmit={handleSubmit}>
        <h2>Rate Your Visit</h2>
        <p>Your feedback helps us improve our service for all students.</p>

        <div className="star-rating">
          {[...Array(5)].map((_, index) => {
            const starValue = index + 1;
            return (
              <span 
                key={starValue}
                className={`star ${starValue <= (hover || rating) ? 'on' : ''}`}
                onClick={() => setRating(starValue)}
                onMouseEnter={() => setHover(starValue)}
                onMouseLeave={() => setHover(0)}
                role="button"
                aria-label={`Rate ${starValue} out of 5 stars`}
              >
                ★
              </span>
            );
          })}
        </div>

        <textarea
          className="comment-textarea"
          placeholder="Tell us more about your experience (optional)..."
          value={comment}
          onChange={(e) => setComment(e.target.value)}
        />
        
        <button type="submit" className="submit-btn" disabled={rating === 0}>
          Submit Feedback
        </button>
      </form>
    </div>
  );
};

export default Feedback;