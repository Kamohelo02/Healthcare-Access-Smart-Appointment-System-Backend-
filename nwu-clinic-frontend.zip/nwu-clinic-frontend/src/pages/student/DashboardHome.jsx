// src/pages/student/DashboardHome.jsx
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import '../../styles/DashboardHome.css';

const DashboardHome = () => {
  const [userData, setUserData] = useState({
    firstName: 'John',
    lastName: 'Doe',
    studentNumber: '12345678'
  });
  
  const [dashboardData, setDashboardData] = useState({
    upcomingAppointments: [],
    recentActivity: [],
    announcements: [],
    quickStats: {
      totalAppointments: 0,
      upcomingAppointments: 0,
      completedAppointments: 0,
      cancelledAppointments: 0
    }
  });
  
  const [loading, setLoading] = useState(true);

  // Simulate loading dashboard data
  useEffect(() => {
    const loadDashboardData = async () => {
      setLoading(true);
      
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Mock data - replace with actual API calls
      setDashboardData({
        upcomingAppointments: [
          {
            id: 1,
            date: '2024-03-25',
            time: '10:30 AM',
            doctor: 'Dr. Sarah Johnson',
            type: 'General Consultation',
            status: 'confirmed'
          },
          {
            id: 2,
            date: '2024-04-02',
            time: '2:15 PM',
            doctor: 'Dr. Michael Brown',
            type: 'Follow-up',
            status: 'pending'
          }
        ],
        recentActivity: [
          {
            id: 1,
            action: 'Appointment Booked',
            description: 'General consultation with Dr. Sarah Johnson',
            timestamp: '2024-03-20 14:30',
            type: 'booking'
          },
          {
            id: 2,
            action: 'Profile Updated',
            description: 'Contact information changed',
            timestamp: '2024-03-18 09:15',
            type: 'profile'
          },
          {
            id: 3,
            action: 'Appointment Completed',
            description: 'Check-up with Dr. Lisa Davis',
            timestamp: '2024-03-15 11:00',
            type: 'completed'
          }
        ],
        announcements: [
          {
            id: 1,
            title: 'New COVID-19 Guidelines',
            message: 'Updated safety protocols are now in effect. Please wear masks and sanitize hands.',
            date: '2024-03-20',
            urgent: true
          },
          {
            id: 2,
            title: 'Extended Hours During Exams',
            message: 'The clinic will be open until 8 PM during exam period (April 1-15).',
            date: '2024-03-18',
            urgent: false
          }
        ],
        quickStats: {
          totalAppointments: 12,
          upcomingAppointments: 2,
          completedAppointments: 8,
          cancelledAppointments: 2
        }
      });
      
      setLoading(false);
    };

    loadDashboardData();
  }, []);

  // Quick action buttons
  const quickActions = [
    {
      title: 'Book Appointment',
      description: 'Schedule a new appointment',
      link: '/student/book',
      icon: '➕',
      color: 'primary'
    },
    {
      title: 'My Appointments',
      description: 'View and manage appointments',
      link: '/student/appointments',
      icon: '📅',
      color: 'secondary'
    },
    {
      title: 'Update Profile',
      description: 'Edit your information',
      link: '/student/profile',
      icon: '👤',
      color: 'accent'
    },
    {
      title: 'View Announcements',
      description: 'Check latest updates',
      link: '/student/announcements',
      icon: '📢',
      color: 'info'
    }
  ];

  if (loading) {
    return (
      <div className="dashboard-loading">
        <div className="loading-spinner"></div>
        <p>Loading your dashboard...</p>
      </div>
    );
  }

  return (
    <div className="dashboard-home">
      {/* Welcome Header */}
      <header className="dashboard-header">
        <div className="welcome-section">
          <h1>Welcome back, {userData.firstName}! 👋</h1>
          <p>Here's what's happening with your healthcare journey</p>
        </div>
        <div className="date-display">
          <span className="current-date">
            {new Date().toLocaleDateString('en-US', { 
              weekday: 'long', 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </span>
        </div>
      </header>

      {/* Quick Stats */}
      <section className="quick-stats">
        <div className="stat-card">
          <div className="stat-icon">📊</div>
          <div className="stat-content">
            <h3>{dashboardData.quickStats.totalAppointments}</h3>
            <p>Total Appointments</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">⏰</div>
          <div className="stat-content">
            <h3>{dashboardData.quickStats.upcomingAppointments}</h3>
            <p>Upcoming</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">✅</div>
          <div className="stat-content">
            <h3>{dashboardData.quickStats.completedAppointments}</h3>
            <p>Completed</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">❌</div>
          <div className="stat-content">
            <h3>{dashboardData.quickStats.cancelledAppointments}</h3>
            <p>Cancelled</p>
          </div>
        </div>
      </section>

      {/* Quick Actions */}
      <section className="quick-actions">
        <h2>Quick Actions</h2>
        <div className="actions-grid">
          {quickActions.map((action, index) => (
            <Link 
              key={index}
              to={action.link}
              className={`action-card ${action.color}`}
            >
              <div className="action-icon">{action.icon}</div>
              <div className="action-content">
                <h3>{action.title}</h3>
                <p>{action.description}</p>
              </div>
              <div className="action-arrow">→</div>
            </Link>
          ))}
        </div>
      </section>

      {/* Main Content Grid */}
      <div className="dashboard-grid">
        {/* Upcoming Appointments */}
        <section className="dashboard-section upcoming-appointments">
          <div className="section-header">
            <h2>Upcoming Appointments</h2>
            <Link to="/student/appointments" className="view-all-link">
              View All →
            </Link>
          </div>
          
          {dashboardData.upcomingAppointments.length > 0 ? (
            <div className="appointments-list">
              {dashboardData.upcomingAppointments.slice(0, 3).map(appointment => (
                <div key={appointment.id} className="appointment-item">
                  <div className="appointment-date">
                    <span className="date">{new Date(appointment.date).getDate()}</span>
                    <span className="month">
                      {new Date(appointment.date).toLocaleDateString('en-US', { month: 'short' })}
                    </span>
                  </div>
                  <div className="appointment-details">
                    <h4>{appointment.type}</h4>
                    <p className="doctor">{appointment.doctor}</p>
                    <p className="time">{appointment.time}</p>
                  </div>
                  <div className={`appointment-status ${appointment.status}`}>
                    {appointment.status}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <div className="empty-icon">📅</div>
              <p>No upcoming appointments</p>
              <Link to="/student/book" className="cta-button">
                Book Your First Appointment
              </Link>
            </div>
          )}
        </section>

        {/* Recent Activity */}
        <section className="dashboard-section recent-activity">
          <div className="section-header">
            <h2>Recent Activity</h2>
          </div>
          
          <div className="activity-list">
            {dashboardData.recentActivity.slice(0, 5).map(activity => (
              <div key={activity.id} className="activity-item">
                <div className={`activity-icon ${activity.type}`}>
                  {activity.type === 'booking' && '➕'}
                  {activity.type === 'profile' && '👤'}
                  {activity.type === 'completed' && '✅'}
                  {activity.type === 'cancelled' && '❌'}
                </div>
                <div className="activity-content">
                  <h4>{activity.action}</h4>
                  <p>{activity.description}</p>
                  <span className="activity-time">
                    {new Date(activity.timestamp).toLocaleDateString('en-US', {
                      month: 'short',
                      day: 'numeric',
                      hour: 'numeric',
                      minute: '2-digit'
                    })}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Announcements */}
        <section className="dashboard-section announcements">
          <div className="section-header">
            <h2>Latest Announcements</h2>
            <Link to="/student/announcements" className="view-all-link">
              View All →
            </Link>
          </div>
          
          <div className="announcements-list">
            {dashboardData.announcements.slice(0, 2).map(announcement => (
              <div key={announcement.id} className={`announcement-item ${announcement.urgent ? 'urgent' : ''}`}>
                <div className="announcement-header">
                  <h4>{announcement.title}</h4>
                  {announcement.urgent && <span className="urgent-badge">Urgent</span>}
                </div>
                <p>{announcement.message}</p>
                <span className="announcement-date">
                  {new Date(announcement.date).toLocaleDateString('en-US', {
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric'
                  })}
                </span>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default DashboardHome;