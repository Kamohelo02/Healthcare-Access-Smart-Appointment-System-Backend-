// src/pages/student/MyAppointments.jsx (Full Code)
import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import '../../styles/MyAppointments.css';

// --- Mock Data ---
// In a real application, this would be fetched from your API.
// It includes various statuses and dates to test all features.
const mockAppointments = [
  { id: 1, date: '2025-10-25', time: '10:30 AM', doctor: 'Dr. Thabo Mbeki', type: 'General Consultation', status: 'confirmed' },
  { id: 2, date: '2025-11-05', time: '02:00 PM', doctor: 'Dr. Zandile Gumede', type: 'Dental Check-up', status: 'confirmed' },
  { id: 3, date: '2025-09-15', time: '09:00 AM', doctor: 'Dr. Sarah Johnson', type: 'Follow-up', status: 'completed' },
  { id: 4, date: '2025-08-22', time: '11:45 AM', doctor: 'Dr. Thabo Mbeki', type: 'General Consultation', status: 'completed' },
  { id: 5, date: '2025-09-10', time: '03:30 PM', doctor: 'Dr. Zandile Gumede', type: 'Sick Note Request', status: 'cancelled' },
  { id: 6, date: '2025-10-28', time: '01:15 PM', doctor: 'Dr. Sarah Johnson', type: 'Vaccination', status: 'confirmed' },
  { id: 7, date: '2025-11-12', time: '08:30 AM', doctor: 'Dr. Thabo Mbeki', type: 'Blood Pressure Check', status: 'pending' },
  { id: 8, date: '2025-07-01', time: '10:00 AM', doctor: 'Dr. Zandile Gumede', type: 'Dental Check-up', status: 'completed' },
  { id: 9, date: '2025-12-01', time: '09:45 AM', doctor: 'Dr. Sarah Johnson', type: 'General Consultation', status: 'confirmed' },
  { id: 10, date: '2025-06-20', time: '02:30 PM', doctor: 'Dr. Thabo Mbeki', type: 'Follow-up', status: 'completed' },
  { id: 11, date: '2025-12-15', time: '04:00 PM', doctor: 'Dr. Zandile Gumede', type: 'Sick Note Request', status: 'pending' },
  { id: 12, date: '2025-05-18', time: '11:00 AM', doctor: 'Dr. Sarah Johnson', type: 'Vaccination', status: 'completed' },
];

// A small helper component to render the status with a nice badge
const StatusBadge = ({ status }) => {
  return <span className={`status-badge ${status}`}>{status}</span>;
};

const MyAppointments = () => {
  // State for all appointments (would come from API)
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);

  // State for filtering, sorting, and pagination
  const [activeFilter, setActiveFilter] = useState('all');
  const [sortConfig, setSortConfig] = useState({ key: 'date', direction: 'descending' });
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // Simulate fetching data on component mount
  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      setAppointments(mockAppointments);
      setLoading(false);
    }, 1000); // Simulate 1-second network delay
  }, []);

  // useMemo will re-calculate the filtered and sorted list only when the dependencies change
  const processedAppointments = useMemo(() => {
    let filteredItems = [...appointments];

    // 1. Filtering Logic
    if (activeFilter !== 'all') {
      if (activeFilter === 'upcoming') {
        const today = new Date().setHours(0, 0, 0, 0);
        filteredItems = filteredItems.filter(appt => 
          (appt.status === 'confirmed' || appt.status === 'pending') && new Date(appt.date) >= today
        );
      } else {
        filteredItems = filteredItems.filter(appt => appt.status === activeFilter);
      }
    }

    // 2. Sorting Logic
    if (sortConfig.key) {
      filteredItems.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'ascending' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'ascending' ? 1 : -1;
        }
        return 0;
      });
    }

    return filteredItems;
  }, [appointments, activeFilter, sortConfig]);

  // 3. Pagination Logic - applied to the already filtered and sorted data
  const paginatedAppointments = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return processedAppointments.slice(startIndex, startIndex + itemsPerPage);
  }, [processedAppointments, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(processedAppointments.length / itemsPerPage);

  // Handler for changing sort column and direction
  const requestSort = (key) => {
    let direction = 'ascending';
    if (sortConfig.key === key && sortConfig.direction === 'ascending') {
      direction = 'descending';
    }
    setSortConfig({ key, direction });
    setCurrentPage(1); // Reset to first page on sort
  };
  
  // Handler for changing filter
  const handleFilterChange = (filter) => {
      setActiveFilter(filter);
      setCurrentPage(1); // Reset to first page on filter change
  };

  const renderSortIndicator = (key) => {
    if (sortConfig.key !== key) return '↕';
    if (sortConfig.direction === 'ascending') return '▲';
    return '▼';
  };

  if (loading) {
      return <div>Loading appointments...</div>;
  }

  return (
    <div className="appointments-container">
      <header className="appointments-header">
        <h1>My Appointments</h1>
      </header>

      {appointments.length === 0 ? (
        <div className="empty-state-container">
            <h3>No Appointments Found</h3>
            <p>You haven't booked any appointments yet. Get started now!</p>
            <Link to="/student/book" className="cta-button">Book an Appointment</Link>
        </div>
      ) : (
        <>
            <div className="appointments-toolbar">
                <div className="filter-group">
                <button onClick={() => handleFilterChange('all')} className={`filter-btn ${activeFilter === 'all' ? 'active' : ''}`}>All</button>
                <button onClick={() => handleFilterChange('upcoming')} className={`filter-btn ${activeFilter === 'upcoming' ? 'active' : ''}`}>Upcoming</button>
                <button onClick={() => handleFilterChange('completed')} className={`filter-btn ${activeFilter === 'completed' ? 'active' : ''}`}>Completed</button>
                <button onClick={() => handleFilterChange('cancelled')} className={`filter-btn ${activeFilter === 'cancelled' ? 'active' : ''}`}>Cancelled</button>
                </div>
            </div>

            <div className="table-wrapper">
                <table className="appointments-table">
                <thead>
                    <tr>
                    <th onClick={() => requestSort('date')}>Date <span className="sort-indicator">{renderSortIndicator('date')}</span></th>
                    <th onClick={() => requestSort('time')}>Time</th>
                    <th onClick={() => requestSort('doctor')}>Doctor <span className="sort-indicator">{renderSortIndicator('doctor')}</span></th>
                    <th onClick={() => requestSort('type')}>Type <span className="sort-indicator">{renderSortIndicator('type')}</span></th>
                    <th onClick={() => requestSort('status')}>Status <span className="sort-indicator">{renderSortIndicator('status')}</span></th>
                    </tr>
                </thead>
                <tbody>
                    {paginatedAppointments.map(appt => (
                    <tr key={appt.id}>
                        <td>{new Date(appt.date).toLocaleDateString('en-ZA', { year: 'numeric', month: 'long', day: 'numeric' })}</td>
                        <td>{appt.time}</td>
                        <td>{appt.doctor}</td>
                        <td>{appt.type}</td>
                        <td><StatusBadge status={appt.status} /></td>
                    </tr>
                    ))}
                </tbody>
                </table>
            </div>

            {totalPages > 1 && (
                <div className="pagination-controls">
                    <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1}>Previous</button>
                    <span className="page-info">Page {currentPage} of {totalPages}</span>
                    <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages}>Next</button>
                </div>
            )}
        </>
      )}
    </div>
  );
};

export default MyAppointments;