// src/pages/student/StudentDashboard.jsx (Full Updated Code)
import React, { useState, useEffect } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import DashboardLayout from '../components/DashboardLayout';

import DashboardHome from './DashboardHome';
import MyAppointments from './MyAppointments';
import BookAppointment from './BookAppointment';
import Profile from '../Profile';
import Announcements from './Announcements';
import FAQ from './FAQ';
import Feedback from './Feedback';

function StudentDashboard() {
  const navigate = useNavigate();
  const [userData, setUserData] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user || user.role !== 'student') {
      navigate('/login');
      return;
    }
    setUserData({
      firstName: user.name?.split(' ')[0] || 'Student',
      lastName: user.name?.split(' ')[1] || 'User',
      email: user.email,
      identifier: '34567890',
    });
    setLoading(false);
  }, [navigate]);

  // FIXED: All 'to' paths are now absolute
  const menuItems = [
    { to: "/student", icon: "🏠", label: "Dashboard", description: "Overview & quick actions" },
    { to: "/student/appointments", icon: "📅", label: "My Appointments", description: "View & manage appointments" },
    { to: "/student/book", icon: "➕", label: "Book Appointment", description: "Schedule new appointment" },
    { to: "/student/profile", icon: "👤", label: "Profile", description: "Manage your profile" },
    { to: "/student/announcements", icon: "📢", label: "Announcements", description: "Latest clinic updates" },
    { to: "/student/faq", icon: "❓", label: "FAQ", description: "Get quick answers" },
    { to: "/student/feedback", icon: "💬", label: "Share your experience" }
  ];

  if (loading) {
    return <div>Loading Student Dashboard...</div>;
  }

  return (
    <DashboardLayout userData={userData} menuItems={menuItems}>
      <Routes>
        <Route index element={<DashboardHome />} />
        <Route path="book" element={<BookAppointment />} />
        <Route path="appointments" element={<MyAppointments />} />
        <Route path="profile" element={<Profile />} />
        <Route path="announcements" element={<Announcements />} />
        <Route path="faq" element={<FAQ />} />
        <Route path="feedback" element={<Feedback />} />
      </Routes>
    </DashboardLayout>
  );
}

export default StudentDashboard;