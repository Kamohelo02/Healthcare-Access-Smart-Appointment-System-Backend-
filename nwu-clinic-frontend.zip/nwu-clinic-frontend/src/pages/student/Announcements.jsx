// src/pages/student/Announcements.jsx (Full Code)
import React, { useState, useEffect } from 'react';
import '../../styles/Announcements.css';

// --- Mock Data ---
// In a real app, this would be fetched from the GET /announcements endpoint
const mockAnnouncements = [
  { 
    id: 1, 
    title: 'Flu Vaccination Drive', 
    content: 'The annual flu vaccination drive begins on October 15th, 2025. All students are encouraged to participate. Book your spot through the "Book Appointment" page by selecting "Vaccination" as the service.',
    date: '2025-09-28',
    urgent: true 
  },
  { 
    id: 2, 
    title: 'Updated Clinic Hours for Spring Break', 
    content: 'Please be advised that the clinic will operate on reduced hours (10:00 AM to 02:00 PM) during the upcoming spring break from October 6th to October 10th, 2025.',
    date: '2025-09-25',
    urgent: false 
  },
  { 
    id: 3, 
    title: 'Introduction of New Telehealth Service', 
    content: 'We are excited to announce the launch of our new telehealth consultation service for minor ailments. You can now book a virtual appointment for a remote consultation with one of our practitioners.',
    date: '2025-09-20',
    urgent: false 
  },
];

const Announcements = () => {
  const [announcements, setAnnouncements] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate fetching announcements from an API
    setLoading(true);
    setTimeout(() => {
      // Sort announcements by date, newest first
      const sortedAnnouncements = mockAnnouncements.sort((a, b) => new Date(b.date) - new Date(a.date));
      setAnnouncements(sortedAnnouncements);
      setLoading(false);
    }, 500);
  }, []);

  if (loading) {
    return <div>Loading announcements...</div>;
  }

  return (
    <div className="announcements-container">
      <header className="announcements-header">
        <h1>Clinic Announcements</h1>
      </header>
      
      <div className="announcements-list">
        {announcements.map(item => (
          <div key={item.id} className={`announcement-card ${item.urgent ? 'urgent' : ''}`}>
            <div className="card-top">
              <h2>{item.title}</h2>
              {item.urgent && <span className="urgent-badge">Urgent</span>}
            </div>
            <p className="announcement-meta">
              Posted on {new Date(item.date).toLocaleDateString('en-ZA', { year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
            <p className="announcement-content">{item.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Announcements;