// src/pages/student/FAQ.jsx (Full Code)
import React, { useState, useEffect } from 'react';
import '../../styles/FAQPage.css';

// --- Mock Data ---
// In a real app, this would be fetched from the GET /faqs endpoint
const faqData = [
  {
    id: 1,
    question: "How do I book an appointment?",
    answer: "You can book an appointment by navigating to the 'Book Appointment' page from the sidebar. From there, select a service, choose an available date and time, and confirm your details."
  },
  {
    id: 2,
    question: "Can I cancel or reschedule my appointment?",
    answer: "Yes. Go to the 'My Appointments' page, find the upcoming appointment you wish to change, and you will see options to either cancel or reschedule it. Please note that cancellations must be made at least 24 hours in advance."
  },
  {
    id: 3,
    question: "What services does the clinic offer?",
    answer: "The clinic offers a range of services including general consultations, dental check-ups, vaccinations, sick note requests, and follow-up visits. You can see all available services on the 'Book Appointment' page."
  },
  {
    id: 4,
    question: "Are the appointments free for registered students?",
    answer: "Yes, standard consultations and services are covered for all registered NWU students. Specialized treatments or medications may incur additional costs."
  },
];

const FAQ = () => {
  const [faqs, setFaqs] = useState([]);
  const [loading, setLoading] = useState(true);

  // This state holds the ID of the currently open question. null means all are closed.
  const [openQuestionId, setOpenQuestionId] = useState(null);

  useEffect(() => {
    // Simulate fetching FAQ data from an API
    setLoading(true);
    setTimeout(() => {
      setFaqs(faqData);
      setLoading(false);
    }, 500);
  }, []);

  // Toggles the accordion item
  const handleToggle = (id) => {
    // If the clicked question is already open, close it. Otherwise, open it.
    setOpenQuestionId(openQuestionId === id ? null : id);
  };

  if (loading) {
    return <div>Loading FAQ...</div>;
  }

  return (
    <div className="faq-container">
      <header className="faq-header">
        <h1>Frequently Asked Questions</h1>
      </header>
      
      <div className="accordion">
        {faqs.map(faq => (
          <div key={faq.id} className={`faq-item ${openQuestionId === faq.id ? 'open' : ''}`}>
            <button className="faq-question" onClick={() => handleToggle(faq.id)}>
              {faq.question}
              <span className="faq-toggle-icon">+</span>
            </button>
            <div className="faq-answer">
              <p>{faq.answer}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FAQ;