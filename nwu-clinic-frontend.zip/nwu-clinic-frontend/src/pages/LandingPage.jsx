import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../styles/LandingPage.css';

const LandingPage = () => {
  const navigate = useNavigate();

  const handleGetStarted = () => {
    // This function is no longer used by a button but kept in case it's needed elsewhere
    navigate('/login');
  };

  return (
    <div className="landing-page">
      {/* Header */}
      <header className="header">
        <div className="container">
          <div className="logo">
            <h2>🏥 NWU Clinic</h2>
          </div>
          <nav className="nav" role="navigation" aria-label="Main navigation">
            <Link to="/login" className="nav-link" aria-label="Login to your account">
              Login
            </Link>
            <Link to="/register" className="nav-link nav-link-primary" aria-label="Create new account">
              Create Account
            </Link>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main>
        {/* Hero Section */}
        <section className="hero" aria-labelledby="hero-title">
          <div className="container">
            <div className="hero-content">
              <h1 id="hero-title" className="hero-title">
                Skip the Queue, Book Online
              </h1>
              <p className="hero-subtitle">
                No more phone calls or waiting in line. Book your clinic appointment 
                at NWU with just a few clicks. Available 24/7 on any device.
              </p>
              {/* The "Book Appointment Now" button has been removed as requested */}
              <p className="hero-note">
                ✨ Quick, secure, and mobile-friendly
              </p>
            </div>
          </div>
        </section>

        {/* Problem/Solution Section */}
        <section className="problem-solution" aria-labelledby="comparison-title">
          <div className="container">
            <h2 id="comparison-title" className="section-title visually-hidden">
              Comparison: Old vs New Way
            </h2>
            <div className="grid-2">
              <div className="problem">
                <h3>❌ The Old Way</h3>
                <ul role="list">
                  <li>Phone during business hours only</li>
                  <li>Wait in long queues</li>
                  <li>Confusion about availability</li>
                  <li>Missed appointments</li>
                </ul>
              </div>
              <div className="solution">
                <h3>✅ The New Way</h3>
                <ul role="list">
                  <li>Book anytime, anywhere</li>
                  <li>See real-time availability</li>
                  <li>Automatic reminders</li>
                  <li>Easy to reschedule</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="features" aria-labelledby="features-title">
          <div className="container">
            <h2 id="features-title" className="section-title">Why Use Our System?</h2>
            <div className="grid-3">
              <div className="feature-card">
                <div className="feature-icon" role="img" aria-label="Calendar icon">📅</div>
                <h3>Easy Online Booking</h3>
                <p>Select your preferred date, time, and clinic type in seconds. No more phone tag with busy reception staff.</p>
              </div>
              <div className="feature-card">
                <div className="feature-icon" role="img" aria-label="Notification bell icon">🔔</div>
                <h3>Smart Notifications</h3>
                <p>Get email and SMS reminders for your appointments. Never miss another booking or forget to reschedule.</p>
              </div>
              <div className="feature-card">
                <div className="feature-icon" role="img" aria-label="Mobile phone icon">📱</div>
                <h3>Mobile Friendly</h3>
                <p>Book and manage appointments from your phone, tablet, or computer. Works perfectly on any device.</p>
              </div>
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="how-it-works" aria-labelledby="process-title">
          <div className="container">
            <h2 id="process-title" className="section-title">How It Works</h2>
            <div className="steps" role="list">
              <div className="step" role="listitem">
                <div className="step-number" aria-label="Step 1">1</div>
                <h3>Create Account</h3>
                <p>Sign up with your student number and email</p>
              </div>
              <div className="step-arrow" aria-hidden="true">→</div>
              <div className="step" role="listitem">
                <div className="step-number" aria-label="Step 2">2</div>
                <h3>Choose Time</h3>
                <p>Pick your preferred date and time slot</p>
              </div>
              <div className="step-arrow" aria-hidden="true">→</div>
              <div className="step" role="listitem">
                <div className="step-number" aria-label="Step 3">3</div>
                <h3>Get Confirmed</h3>
                <p>Receive instant confirmation and reminders</p>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="footer" role="contentinfo">
        <div className="container">
          <div className="footer-content">
            <div className="footer-section">
              <h4>🏥 NWU Clinic System</h4>
              <p>Making healthcare access easier for students</p>
            </div>
            {/* "Quick Links" section removed as requested */}
            {/* "For Students" section removed as requested */}
          </div>
          <div className="footer-bottom">
            <p>&copy; 2025 NWU Clinic Appointment System. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;