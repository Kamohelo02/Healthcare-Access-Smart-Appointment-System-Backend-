import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../styles/LoginPage.css';

const LoginPage = () => {
  const navigate = useNavigate();
  
  // Form state
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  
  // Loading and error states
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  
  // Handle input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user starts typing
    if (error) {
      setError('');
    }
  };
  
  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');
    
    // Basic validation
    if (!formData.email || !formData.password) {
      setError('Please fill in all fields');
      setIsLoading(false);
      return;
    }
    
    if (!isValidEmail(formData.email)) {
      setError('Please enter a valid email address');
      setIsLoading(false);
      return;
    }
    
    try {
      // Simulate API call
      console.log('Login attempt:', formData);
      const result = await simulateLogin(formData);
      
      // Store authentication state
      localStorage.setItem('isAuthenticated', 'true');
      localStorage.setItem('userRole', result.role);
      localStorage.setItem('user', JSON.stringify({
        email: formData.email,
        role: result.role,
        name: result.name
      }));
      
      // Navigate based on user role
      switch (result.role) {
        case 'student':
          navigate('/student');
          break;
        case 'staff':
          navigate('/staff/dashboard');
          break;
        case 'admin':
          navigate('/admin/dashboard');
          break;
        default:
          navigate('/student');
      }
      
    } catch (err) {
      setError(err.message || 'Login failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };
  
  // Email validation helper
  const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };
  
  // Simulate login API call
  const simulateLogin = async (credentials) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        const demoUsers = [
            { email: 'student@nwu.ac.za', password: 'NWUStudent2024!', role: 'student', name: 'John Doe' },
            { email: 'sarah.nurse@nwu.ac.za', password: 'NurseAccess2024#', role: 'staff', name: 'Sarah Johnson' },
            { email: 'admin@nwu.ac.za', password: 'AdminSecure2024$', role: 'admin', name: 'Dr. Michael Chen' },
            { email: 'demo.user@nwu.ac.za', password: 'DemoClinic2024@', role: 'student', name: 'Demo User' },
            { email: 'clinic.staff@nwu.ac.za', password: 'StaffPortal2024&', role: 'staff', name: 'Lisa Martinez' }
        ];
        
        const user = demoUsers.find(u => u.email === credentials.email && u.password === credentials.password);
        
        if (user) {
          resolve({ success: true, role: user.role, name: user.name });
        } else {
          reject(new Error('Invalid email or password. Please check your credentials and try again.'));
        }
      }, 1500);
    });
  };
  
  return (
    <div className="login-page">
      {/* Header */}
      <header className="login-header">
        <div className="container">
          <Link to="/" className="logo" aria-label="Go back to home page">
            <h2>🏥 NWU Clinic</h2>
          </Link>
        </div>
      </header>
      
      <main className="login-main">
        <div className="login-content-wrapper">
          
          {/* Column 1: Illustration & Branding */}
          <div className="login-illustration">
            <div className="illustration-content">
              <h3>Your Health, On Your Schedule</h3>
              <p>Book and manage your campus clinic appointments with ease. Fast, confidential, and convenient access to NWU healthcare services.</p>
            </div>
          </div>
  
          {/* Column 2: The Login Form Area - THIS IS THE KEY CHANGE */}
          <div className="login-form-area">
            <div className="login-card">
              {/* Login Form Header */}
              <div className="login-header-content">
                <h1>Welcome Back</h1>
                <p>Sign in to your NWU Clinic account</p>
              </div>
              
              {/* Error Message */}
              {error && (
                <div className="error-message" role="alert" aria-live="polite">
                  <span className="error-icon">⚠️</span>
                  {error}
                </div>
              )}
              
              {/* Login Form */}
              <form onSubmit={handleSubmit} className="login-form" noValidate>
                <div className="form-group">
                  <label htmlFor="email" className="form-label">Email Address</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="form-input"
                    placeholder="your.email@nwu.ac.za"
                    required
                    autoComplete="email"
                    aria-describedby={error ? "error-message" : undefined}
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="password" className="form-label">Password</label>
                  <input
                    type="password"
                    id="password"
                    name="password"
                    value={formData.password}
                    onChange={handleInputChange}
                    className="form-input"
                    placeholder="Enter your password"
                    required
                    autoComplete="current-password"
                    aria-describedby={error ? "error-message" : undefined}
                  />
                </div>
                
                {/* Login Button */}
                <button
                  type="submit"
                  className="login-button"
                  disabled={isLoading}
                  aria-describedby="login-status"
                >
                  {isLoading ? (
                    <>
                      <span className="spinner" aria-hidden="true"></span>
                      Signing In...
                    </>
                  ) : (
                    'Sign In'
                  )}
                </button>
              </form>
              
              {/* Additional Options */}
              <div className="login-footer">
                <Link to="/forgot-password" className="forgot-link">
                  Forgot your password?
                </Link>
                
                <div className="signup-prompt">
                  Don't have an account?{' '}
                  <Link to="/register" className="signup-link">
                    Create Account
                  </Link>
                </div>
              </div>
              
              {/* Demo Credentials (remove in production) */}
              <div className="demo-info">
                <h4>Demo Credentials for Testing:</h4>
                <div className="credentials-grid">
                  <div className="credential-item">
                    <strong>Student Account:</strong><br />
                    <span>student@nwu.ac.za</span><br />
                    <span>NWUStudent2024!</span>
                  </div>
                  <div className="credential-item">
                    <strong>Staff Account:</strong><br />
                    <span>sarah.nurse@nwu.ac.za</span><br />
                    <span>NurseAccess2024#</span>
                  </div>
                  <div className="credential-item">
                    <strong>Admin Account:</strong><br />
                    <span>admin@nwu.ac.za</span><br />
                    <span>AdminSecure2024$</span>
                  </div>
                   <div className="credential-item">
                    <strong>Demo User:</strong><br />
                    <span>demo.user@nwu.ac.za</span><br />
                    <span>DemoClinic2024@</span>
                  </div>
                </div>
                <p className="demo-note">
                  <em>Note: These are demonstration accounts only. In production, users will register with their own credentials.</em>
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      {/* Footer */}
      <footer className="login-footer-section">
        <div className="container">
          <p>&copy; 2024 NWU Clinic Appointment System. All rights reserved.</p>
          <div className="footer-links">
            <Link to="/privacy">Privacy Policy</Link>
            <Link to="/terms">Terms of Service</Link>
            <Link to="/support">Support</Link>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LoginPage;