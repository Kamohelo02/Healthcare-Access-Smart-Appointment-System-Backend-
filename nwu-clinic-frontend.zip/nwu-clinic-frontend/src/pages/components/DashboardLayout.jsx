// src/pages/components/DashboardLayout.jsx (Final Code)
import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import '../../styles/DashboardLayout.css'; // Points to our new, correct CSS file

const DashboardLayout = ({ userData, menuItems, children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem('isAuthenticated');
    localStorage.removeItem('userRole');
    localStorage.removeItem('user');
    navigate('/login');
  };

  const toggleSidebar = () => setIsSidebarOpen(!isSidebarOpen);
  const closeSidebar = () => setIsSidebarOpen(false);

  // Note: All classNames now match the generic styles in DashboardLayout.css
  return (
    <div className="dashboard-layout">
      {isSidebarOpen && <div className="sidebar-overlay" onClick={closeSidebar} />}
      
      <nav className={`dashboard-sidebar ${isSidebarOpen ? 'sidebar-open' : ''}`}>
        <div className="sidebar-header">
          <div className="user-avatar">
            {userData.firstName?.charAt(0)}{userData.lastName?.charAt(0)}
          </div>
          <div className="user-info">
            <h3>{userData.firstName} {userData.lastName}</h3>
            <p>{userData.identifier}</p>
            <span className="user-email">{userData.email}</span>
          </div>
        </div>
        
        <div className="sidebar-menu">
          {menuItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
              onClick={closeSidebar}
              end={item.to === ""}
            >
              <span className="menu-icon">{item.icon}</span>
              <div className="menu-content">
                <span className="menu-label">{item.label}</span>
                <span className="menu-description">{item.description}</span>
              </div>
            </NavLink>
          ))}
        </div>
        
        <div className="sidebar-footer">
          <button onClick={handleLogout} className="logout-btn">
            <span className="menu-icon">🚪</span>
            <span>Logout</span>
          </button>
        </div>
      </nav>

      <main className="dashboard-content">
        <header className="mobile-header">
          <button className="sidebar-toggle" onClick={toggleSidebar} aria-label="Toggle navigation menu">
            <span className="hamburger-line"></span>
            <span className="hamburger-line"></span>
            <span className="hamburger-line"></span>
          </button>
          <h1>NWU Medical Clinic</h1>
          <div className="header-user">
            <span className="user-greeting">Hi, {userData.firstName}!</span>
          </div>
        </header>
        
        <div className="page-content">
          {children}
        </div>
      </main>
    </div>
  );
};

export default DashboardLayout;