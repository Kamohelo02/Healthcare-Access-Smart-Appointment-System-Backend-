import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../styles/RegisterPage.css';

const RegisterPage = () => {
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    studentNumber: '',
    position: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    userType: 'student'
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  
  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };
  
  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.firstName.trim()) newErrors.firstName = 'First name is required';
    if (!formData.lastName.trim()) newErrors.lastName = 'Last name is required';
    
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    
    if (formData.userType === 'student') {
      if (!formData.studentNumber.trim()) {
        newErrors.studentNumber = 'Student number is required';
      } else if (!/^\d{8,10}$/.test(formData.studentNumber.trim())) {
        newErrors.studentNumber = 'Student number must be 8-10 digits';
      }
    }
    
    if (formData.userType === 'staff') {
      if (!formData.position.trim()) {
        newErrors.position = 'Position is required for staff members';
      }
    }
    
    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    } else if (!/^[0-9\s\-\+\(\)]{10,15}$/.test(formData.phone.trim())) {
      newErrors.phone = 'Please enter a valid phone number';
    }
    
    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 8) {
      newErrors.password = 'Password must be at least 8 characters';
    } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(formData.password)) {
      newErrors.password = 'Password must contain uppercase, lowercase, and a number';
    }
    
    if (!formData.confirmPassword) {
      newErrors.confirmPassword = 'Please confirm your password';
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }
    
    return newErrors;
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    const formErrors = validateForm();
    if (Object.keys(formErrors).length > 0) {
      setErrors(formErrors);
      setIsLoading(false);
      return;
    }
    
    const payload = {
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: formData.phone,
        password: formData.password,
        role: formData.userType,
    };

    if (formData.userType === 'student') {
        payload.studentNumber = formData.studentNumber;
    } else if (formData.userType === 'staff') {
        payload.position = formData.position;
    }

    try {
      console.log('Submitting payload to backend:', payload);
      await simulateRegistration(payload);
      
      alert('Registration successful! Please check your email for verification.');
      navigate('/login');
      
    } catch (err) {
      setErrors({ general: err.message || 'Registration failed. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };
  
  const simulateRegistration = async (userData) => {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        if (userData.email === 'existing@nwu.ac.za') {
          reject(new Error('An account with this email already exists'));
        } else {
          resolve({ success: true });
        }
      }, 2000);
    });
  };
  
  return (
    <div className="register-page">
      <header className="register-header">
        <div className="container">
          <Link to="/" className="logo" aria-label="Go back to home page">
            <h2>🏥 NWU Clinic</h2>
          </Link>
        </div>
      </header>
      
      <main className="register-main">
        {/* ================================================================= */}
        {/* == NEW WRAPPER TO CREATE THE TWO-COLUMN LAYOUT                 == */}
        {/* ================================================================= */}
        <div className="register-content-wrapper">
          
          {/* Column 1: Illustration Panel */}
          <div className="register-illustration">
            <div className="illustration-content">
              <h3>Secure & Confidential</h3>
              <p>Your personal information is protected. Register once to get fast and easy access to campus healthcare services.</p>
            </div>
          </div>
  
          {/* Column 2: The Registration Form Area */}
          <div className="register-form-area">
            <div className="register-card">
              <div className="register-header-content">
                <h1>Create Your Account</h1>
                <p>Join the NWU Clinic appointment system</p>
              </div>
              
              {errors.general && (
                <div className="error-message" role="alert" aria-live="polite">
                  <span className="error-icon">⚠️</span>
                  {errors.general}
                </div>
              )}
              
              <form onSubmit={handleSubmit} className="register-form" noValidate>
                {/* Your form fields remain the same inside here... */}
                <div className="form-group">
                  <label className="form-label">I am a:</label>
                  <div className="radio-group">
                    <label className="radio-option">
                      <input type="radio" name="userType" value="student" checked={formData.userType === 'student'} onChange={handleInputChange} />
                      <span className="radio-custom"></span>
                      Student
                    </label>
                    <label className="radio-option">
                      <input type="radio" name="userType" value="staff" checked={formData.userType === 'staff'} onChange={handleInputChange} />
                      <span className="radio-custom"></span>
                      Clinic Staff
                    </label>
                  </div>
                </div>
                
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="firstName" className="form-label">First Name *</label>
                    <input type="text" id="firstName" name="firstName" value={formData.firstName} onChange={handleInputChange} className={`form-input ${errors.firstName ? 'error' : ''}`} placeholder="Enter your first name" required autoComplete="given-name" />
                    {errors.firstName && <span className="field-error" role="alert">{errors.firstName}</span>}
                  </div>
                  <div className="form-group">
                    <label htmlFor="lastName" className="form-label">Last Name *</label>
                    <input type="text" id="lastName" name="lastName" value={formData.lastName} onChange={handleInputChange} className={`form-input ${errors.lastName ? 'error' : ''}`} placeholder="Enter your last name" required autoComplete="family-name" />
                    {errors.lastName && <span className="field-error" role="alert">{errors.lastName}</span>}
                  </div>
                </div>

                {formData.userType === 'student' && (
                  <div className="form-group">
                    <label htmlFor="studentNumber" className="form-label">Student Number *</label>
                    <input type="text" id="studentNumber" name="studentNumber" value={formData.studentNumber} onChange={handleInputChange} className={`form-input ${errors.studentNumber ? 'error' : ''}`} placeholder="Enter your student number" required autoComplete="off" />
                    {errors.studentNumber && <span className="field-error" role="alert">{errors.studentNumber}</span>}
                  </div>
                )}
                
                {formData.userType === 'staff' && (
                  <div className="form-group">
                    <label htmlFor="position" className="form-label">Position / Title *</label>
                    <input type="text" id="position" name="position" value={formData.position} onChange={handleInputChange} className={`form-input ${errors.position ? 'error' : ''}`} placeholder="e.g., Nurse, Administrator" required />
                    {errors.position && <span className="field-error" role="alert">{errors.position}</span>}
                  </div>
                )}
                
                {/* ...rest of your form fields... */}

                <div className="register-footer">
                  <div className="login-prompt">
                    Already have an account?{' '}
                    <Link to="/login" className="login-link">Sign In</Link>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </main>
      
      <footer className="register-footer-section">
        <div className="container">
          <p>&copy; 2025 NWU Clinic Appointment System. All rights reserved.</p>
          <div className="footer-links">
            <Link to="/support">Support</Link>
            <Link to="/contact">Contact</Link>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default RegisterPage;