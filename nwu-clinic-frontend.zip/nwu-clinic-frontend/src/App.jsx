// src/App.jsx (Full Corrected Code)
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// Import Page Components
import LandingPage from './pages/LandingPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';

// Import Dashboard Components
import StudentDashboard from './pages/student/StudentDashboard';
// FIXED: Corrected the import paths by removing "-new"
import StaffDashboard from './pages/staff/StaffDashboard'; 
import AdminDashboard from './pages/admin/AdminDashboard'; 

import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          {/* Landing Page - Default Route */}
          <Route path="/" element={<LandingPage />} />
          
          {/* Authentication Routes */}
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          
          {/* Dashboard Routes */}
          <Route path="/student/*" element={<StudentDashboard />} />
          <Route path="/staff/dashboard/*" element={<StaffDashboard />} />
          <Route path="/admin/dashboard/*" element={<AdminDashboard />} />

          {/* Catch-all route for pages that don't exist */}
          <Route path="*" element={<div>Page Not Found</div>} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;