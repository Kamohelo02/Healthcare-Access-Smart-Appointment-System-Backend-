export const MIN_PASSWORD_LENGTH = 6;

/**
 * Checks if an email looks valid.
 * We keep the regex simple on purpose: good enough for UI validation.
 * Backend will still do strict validation.
 */
export const isValidEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(String(email).trim());    
};

/**
 * Checks if password meets the minimum length.
 *  can add more rules later (numbers/symbols/etc.).
 */
export const isValidPassword = (password) => {
  return String(password).length >= MIN_PASSWORD_LENGTH;
};

/**
 * Combined check used by login forms.
 * Returns true only if BOTH email and password are valid.
 */
export const validateLogin = (email, password) => {
  return isValidEmail(email) && isValidPassword(password);
};